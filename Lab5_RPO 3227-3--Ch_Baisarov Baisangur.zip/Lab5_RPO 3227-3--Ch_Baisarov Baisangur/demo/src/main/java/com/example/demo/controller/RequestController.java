package com.example.demo.controller;

import com.example.demo.service.CoursesService;
import com.example.demo.service.OperatorsService;
import com.example.demo.service.RequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Controller
@RequestMapping("/requests")
@RequiredArgsConstructor
public class RequestController {

    private final RequestService requestService;
    private final CoursesService coursesService;
    private final OperatorsService operatorsService;

    @GetMapping
    public String getAllRequests(Model model) {
        model.addAttribute("requests", requestService.getAllApplicationRequest());
        model.addAttribute("courses", coursesService.getAllCourses());
        return "requests";
    }

    @GetMapping("/{id}")
    public String getRequest(@PathVariable Long id, Model model) {
        model.addAttribute("request", requestService.getApplicationRequestById(id));
        model.addAttribute("operators", operatorsService.getAllOperators());
        return "request-detail";
    }

    @PostMapping("/add")
    public String addRequest(@RequestParam String userName,
                             @RequestParam String commentary,
                             @RequestParam String phone,
                             @RequestParam Long courseId) {
        requestService.addRequest(userName, commentary, phone, courseId);
        return "redirect:/requests";
    }

    @GetMapping("/{id}/process")
    public String processRequest(@PathVariable Long id, Model model) {
        model.addAttribute("request", requestService.getApplicationRequestById(id));
        model.addAttribute("operators", operatorsService.getAllOperators());
        return "process-request";
    }

    @PostMapping("/{id}/assign")
    public String assignOperators(@PathVariable Long id,
                                  @RequestParam List<Long> operatorIds) {
        requestService.addOperators(id, operatorIds);
        return "redirect:/requests/" + id;
    }

    @PostMapping("/{id}/delete")
    public String deleteRequest(@PathVariable Long id) {
        requestService.deleteRequest(id);
        return "redirect:/requests";
    }
    @PostMapping("/{requestId}/remove-operator/{operatorId}")
    public String removeOperator(@PathVariable Long requestId, @PathVariable Long operatorId) {
        requestService.removeOperatorFromRequest(requestId, operatorId);
        return "redirect:/requests/" + requestId;
    }
}