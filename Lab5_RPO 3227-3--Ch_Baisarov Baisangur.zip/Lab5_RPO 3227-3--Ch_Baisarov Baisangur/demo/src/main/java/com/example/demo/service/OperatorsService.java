package com.example.demo.service;

import com.example.demo.entity.Operators;
import com.example.demo.repository.OperatorsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OperatorsService {
    private final OperatorsRepository operatorsRepository;

    public List<Operators> getAllOperators(){
        return operatorsRepository.findAll();
    }

    public Operators getOperatorById(Long id){
        return operatorsRepository.findById(id).orElse(null);
    }

    public void addOperator(Operators operators){
        operatorsRepository.save(operators);
    }

    public void deleteOperator(Long id){
        operatorsRepository.deleteById(id);
    }
}
