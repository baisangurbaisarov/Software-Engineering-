package com.example.demo.service;

import com.example.demo.entity.ApplicationRequest;
import com.example.demo.entity.Courses;
import com.example.demo.entity.Operators;
import com.example.demo.repository.RequestRepository;
import com.example.demo.repository.CoursesRepository;
import com.example.demo.repository.OperatorsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RequestService {
    private final RequestRepository requestRepository;
    private final OperatorsRepository operatorsRepository;
    private final CoursesRepository coursesRepository;

    public List<ApplicationRequest> getAllApplicationRequest(){
        return requestRepository.findAll();
    }

    public ApplicationRequest getApplicationRequestById(Long id){
        return requestRepository.findById(id).orElse(null);
    }

    public List<ApplicationRequest> getPendingRequests() {
        return requestRepository.findByHandled(false);
    }

    public List<ApplicationRequest> getProcessedRequests() {
        return requestRepository.findByHandled(true);
    }

    @Transactional
    public void addRequest(String userName, String commentary,
                              String phone, Long courseId) {
        ApplicationRequest request = new ApplicationRequest();
        request.setUserName(userName);
        request.setCommentary(commentary);
        request.setPhone(phone);
        request.setHandled(false);
        Courses course = coursesRepository.findById(courseId).orElse(null);
        request.setCourse(course);
        requestRepository.save(request);
    }

    @Transactional
    public void addOperators(Long requestId, List<Long> operatorIds) {
        ApplicationRequest request = requestRepository.findById(requestId).orElse(null);
        if (request != null && !request.isHandled()) {
            List<Operators> operators = request.getOperators();
            for (Long operatorId : operatorIds) {
                Operators operator = operatorsRepository.findById(operatorId).orElse(null);
                if (operator != null) {
                    operators.add(operator);
                }
            }
            request.setHandled(true);
            requestRepository.save(request);
        }
    }

    @Transactional
    public void removeOperatorFromRequest(Long requestId, Long operatorId) {
        ApplicationRequest request = requestRepository.findById(requestId).orElse(null);
        if (request == null) {
            return;
        }
        request.getOperators().removeIf(op -> op.getId().equals(operatorId));
        if (request.getOperators().isEmpty()) {
            request.setHandled(false);
        }
        requestRepository.save(request);
    }

    public void deleteRequest(Long id) {
        requestRepository.deleteById(id);
    }
}

