package com.example.demo.repository;

import com.example.demo.entity.Operators;
import org.springframework.data.jpa.repository.JpaRepository;
public interface OperatorsRepository extends JpaRepository<Operators, Long> {
}
