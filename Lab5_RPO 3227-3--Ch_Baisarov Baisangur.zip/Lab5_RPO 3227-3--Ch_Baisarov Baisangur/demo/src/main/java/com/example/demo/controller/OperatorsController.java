package com.example.demo.controller;

import com.example.demo.entity.Operators;
import com.example.demo.service.OperatorsService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/operators")
@RequiredArgsConstructor

public class OperatorsController {
    private final OperatorsService operatorsService;

    @PostMapping("/add")
    public String addOperator(@RequestParam String name,
                              @RequestParam String surname,
                              @RequestParam String department) {
        Operators operator = new Operators();
        operator.setName(name);
        operator.setSurname(surname);
        operator.setDepartment(department);
        operatorsService.addOperator(operator);
        return "redirect:/requests";
    }

    @PostMapping("/delete")
    public String deleteOperator(@RequestParam Long id) {
        operatorsService.deleteOperator(id);
        return "redirect:/requests";
    }
}
