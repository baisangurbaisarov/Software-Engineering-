package com.example.demo.service;

import com.example.demo.entity.Operators;
import com.example.demo.repository.OperatorsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OperatorsService {
    private final OperatorsRepository operatorsRepository;

    public List<Operators> getAllOperators(){
        return operatorsRepository.findAll();
    }

    public Operators getOperatorById(Long id){
        return operatorsRepository.findById(id).orElse(null);
    }

    public Operators addOperator(String name, String surname, String department) {
        Operators operator = new Operators();
        operator.setName(name);
        operator.setSurname(surname);
        operator.setDepartment(department);
        return operatorsRepository.save(operator);
    }

    @Transactional
    public Operators updateOperator(Long id, String name, String surname, String department) {
        Operators operator = operatorsRepository.findById(id).orElse(null);
        if (operator != null) {
            if (name != null) {
                operator.setName(name);
            }
            if (surname != null) {
                operator.setSurname(surname);
            }
            if (department != null) {
                operator.setDepartment(department);
            }
            return operatorsRepository.save(operator);
        }
        return null;
    }

    public void deleteOperator(Long id){
        operatorsRepository.deleteById(id);
    }
}