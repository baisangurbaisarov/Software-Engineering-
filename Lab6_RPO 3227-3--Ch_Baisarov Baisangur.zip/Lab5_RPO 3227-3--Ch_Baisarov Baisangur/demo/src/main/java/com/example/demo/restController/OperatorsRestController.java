package com.example.demo.restController;

import com.example.demo.entity.ApplicationRequest;
import com.example.demo.entity.Operators;
import com.example.demo.service.OperatorsService;
import com.example.demo.service.RequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/operators")
@RequiredArgsConstructor
public class OperatorsRestController {

    private final OperatorsService operatorsService;
    private final RequestService requestService;

    @GetMapping
    public List<Operators> getAllOperators() {
        return operatorsService.getAllOperators();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Operators> getOperatorById(@PathVariable Long id) {
        Operators operator = operatorsService.getOperatorById(id);
        if (operator == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(operator);
    }

    @PostMapping
    public ResponseEntity<Operators> addOperator(
            @RequestParam String name,
            @RequestParam String surname,
            @RequestParam String department) {

        Operators operator = operatorsService.addOperator(name, surname, department);
        return ResponseEntity.ok(operator);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Operators> updateOperator(
            @PathVariable Long id,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String surname,
            @RequestParam(required = false) String department) {

        Operators operator = operatorsService.updateOperator(id, name, surname, department);
        if (operator == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(operator);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteOperator(@PathVariable Long id) {
        operatorsService.deleteOperator(id);
        return ResponseEntity.ok("Operator deleted successfully");
    }

    @PutMapping("/{id}/assign/{requestId}")
    public ResponseEntity<ApplicationRequest> assignOperator(
            @PathVariable Long id,
            @PathVariable Long requestId) {

        requestService.addOperators(requestId, List.of(id));
        ApplicationRequest request = requestService.getApplicationRequestById(requestId);

        if (request == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(request);
    }
}