package com.example.demo.restController;

import com.example.demo.entity.ApplicationRequest;
import com.example.demo.service.RequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/requests")
@RequiredArgsConstructor
public class ApplicationRequestRestController {

    private final RequestService requestService;

    @GetMapping
    public List<ApplicationRequest> getAllRequests() {
        return requestService.getAllApplicationRequest();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApplicationRequest> getRequestById(@PathVariable Long id) {
        ApplicationRequest request = requestService.getApplicationRequestById(id);
        if (request == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(request);
    }

    @PostMapping
    public ResponseEntity<String> addRequest(
            @RequestParam String userName,
            @RequestParam String commentary,
            @RequestParam String phone,
            @RequestParam Long courseId) {

        requestService.addRequest(userName, commentary, phone, courseId);
        return ResponseEntity.ok("Request created successfully");
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApplicationRequest> updateRequest(
            @PathVariable Long id,
            @RequestParam(required = false) String userName,
            @RequestParam(required = false) String commentary,
            @RequestParam(required = false) String phone,
            @RequestParam(required = false) Long courseId,
            @RequestParam(required = false) Boolean handled) {

        ApplicationRequest request = requestService.updateRequest(id, userName, commentary,
                phone, courseId, handled);
        if (request == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteRequest(@PathVariable Long id) {
        requestService.deleteRequest(id);
        return ResponseEntity.ok("Request deleted successfully");
    }

}