package com.example.demo.controller;


import com.example.demo.service.OperatorsService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

@Controller
@RequestMapping("/operators")
@RequiredArgsConstructor

public class OperatorsController {
    private final OperatorsService operatorsService;

    @GetMapping
    public String listOperators(Model model) {
        model.addAttribute("operators", operatorsService.getAllOperators());
        return "operators";
    }

    @PostMapping("/delete")
    public String deleteOperator(@RequestParam Long id) {
        operatorsService.deleteOperator(id);
        return "redirect:/requests";
    }
}
