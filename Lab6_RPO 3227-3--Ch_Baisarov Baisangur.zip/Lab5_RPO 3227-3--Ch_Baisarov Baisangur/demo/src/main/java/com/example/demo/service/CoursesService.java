package com.example.demo.service;

import com.example.demo.entity.Courses;
import com.example.demo.repository.CoursesRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CoursesService {
    private final CoursesRepository coursesRepository;

    public List<Courses> getAllCourses(){
        return coursesRepository.findAll();
    }

    public Courses getCoursesById(Long id){
        return coursesRepository.findById(id).orElse(null);
    }

    public Courses addCourse(String name, String description, int price) {
        Courses course = new Courses();
        course.setName(name);
        course.setDescription(description);
        course.setPrice(price);
        return coursesRepository.save(course);
    }

    @Transactional
    public Courses updateCourse(Long id, String name, String description, Integer price) {
        Courses course = coursesRepository.findById(id).orElse(null);
        if (course != null) {
            if (name != null) {
                course.setName(name);
            }
            if (description != null) {
                course.setDescription(description);
            }
            if (price != null) {
                course.setPrice(price);
            }
            return coursesRepository.save(course);
        }
        return null;
    }

    public void deleteCourse(Long id) {
        coursesRepository.deleteById(id);
    }
}