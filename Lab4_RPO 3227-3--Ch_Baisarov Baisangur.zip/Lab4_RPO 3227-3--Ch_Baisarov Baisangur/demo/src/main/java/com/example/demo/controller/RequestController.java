package com.example.demo.controller;

import com.example.demo.model.ApplicationRequest;
import com.example.demo.service.RequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class RequestController {

    private final RequestService service;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("requests", service.getAllRequests());
        return "index";
    }

    @GetMapping("/pending")
    public String pendingRequests(Model model) {
        model.addAttribute("requests", service.getPendingRequests());
        return "pending-requests";
    }

    @GetMapping("/processed")
    public String processedRequests(Model model) {
        model.addAttribute("requests", service.getProcessedRequests());
        return "processed-requests";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("request", new ApplicationRequest());
        return "add-request";
    }

    @PostMapping("/add")
    public String addRequest(@ModelAttribute ApplicationRequest request) {
        System.out.println("Commentary: " + request.getCommentary());
        service.saveRequest(request);
        return "redirect:/";
    }

    @GetMapping("/view/{id}")
    public String viewRequest(@PathVariable Long id, Model model) {
        service.getRequestById(id).ifPresent(request ->
                model.addAttribute("request", request)
        );
        return "view-request";
    }

    @PostMapping("/process/{id}")
    public String processRequest(@PathVariable Long id) {
        service.processRequest(id);
        return "redirect:/view/" + id;
    }

    @PostMapping("/delete/{id}")
    public String deleteRequest(@PathVariable Long id) {
        service.deleteRequest(id);
        return "redirect:/";
    }
}