package com.example.demo.service;

import com.example.demo.model.ApplicationRequest;
import com.example.demo.repository.RequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class RequestService {

    private final RequestRepository repository;

    public List<ApplicationRequest> getAllRequests() {
        return repository.findAll();
    }

    public List<ApplicationRequest> getPendingRequests() {
        return repository.findByHandled(false);
    }

    public List<ApplicationRequest> getProcessedRequests() {
        return repository.findByHandled(true);
    }

    public Optional<ApplicationRequest> getRequestById(Long id) {
        return repository.findById(id);
    }

    @Transactional
    public ApplicationRequest saveRequest(ApplicationRequest request) {
        return repository.save(request);
    }

    @Transactional
    public void processRequest(Long id) {
        repository.findById(id).ifPresent(request -> {
            request.setHandled(true);
            repository.save(request);
        });
    }

    @Transactional
    public void deleteRequest(Long id) {
        repository.deleteById(id);
    }
}