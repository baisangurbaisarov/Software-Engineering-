package com.example.demo.mapper;

import com.example.demo.dto.ItemDto;
import com.example.demo.entity.Item;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface ItemMapper {

    @Mapping(source = "manufacturer.id", target = "manufacturerId")
    @Mapping(source = "manufacturer.name", target = "manufacturerName")
    ItemDto toDto(Item item);

    @Mapping(source = "manufacturerId", target = "manufacturer.id")
    @Mapping(target = "manufacturer.name", ignore = true)
    @Mapping(target = "manufacturer.code", ignore = true)
    Item toEntity(ItemDto itemDto);

    List<ItemDto> toDtoList(List<Item> items);

    List<Item> toEntityList(List<ItemDto> itemDtos);
}