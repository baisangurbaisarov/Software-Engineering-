package com.example.demo.service;

import com.example.demo.dto.CountryDto;
import com.example.demo.entity.Country;
import com.example.demo.mapper.CountryMapper;
import com.example.demo.repository.CountryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CountryService {

    private final CountryRepository countryRepository;
    private final CountryMapper countryMapper;

    public List<CountryDto> findAll() {
        return countryMapper.toDtoList(countryRepository.findAll());
    }

    public CountryDto findById(Long id) {
        Country country = countryRepository.findById(id).orElse(null);
        return countryMapper.toDto(country);
    }

    @Transactional
    public CountryDto create(CountryDto countryDto) {
        Country country = countryMapper.toEntity(countryDto);
        Country saved = countryRepository.save(country);
        return countryMapper.toDto(saved);
    }

    @Transactional
    public CountryDto update(Long id, CountryDto countryDto) {
        Country existing = countryRepository.findById(id).orElse(null);

        existing.setName(countryDto.getName());
        existing.setCode(countryDto.getCode());

        Country updated = countryRepository.save(existing);
        return countryMapper.toDto(updated);
    }

    @Transactional
    public void delete(Long id) {
        if (!countryRepository.existsById(id)) {
            throw new RuntimeException("Country not found with id: " + id);
        }
        countryRepository.deleteById(id);
    }
}