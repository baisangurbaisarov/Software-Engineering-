package com.example.demo.mapper;

import com.example.demo.dto.ItemDto;
import com.example.demo.entity.Country;
import com.example.demo.entity.Item;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
class ItemMapperTest {

    @Autowired
    private ItemMapper itemMapper;

    @Test
    void convertEntityToDtoTest() {
        Country manufacturer = Country.builder()
                .id(1L)
                .name("USA")
                .code("US")
                .build();

        Item item = Item.builder()
                .id(1L)
                .name("iPhone 15 Pro")
                .price(999)
                .quantity(50)
                .manufacturer(manufacturer)
                .build();

        ItemDto itemDto = itemMapper.toDto(item);

        Assertions.assertNotNull(itemDto);
        Assertions.assertNotNull(itemDto.getId());
        Assertions.assertNotNull(itemDto.getName());
        Assertions.assertNotNull(itemDto.getPrice());
        Assertions.assertNotNull(itemDto.getQuantity());
        Assertions.assertNotNull(itemDto.getManufacturerId());
        Assertions.assertNotNull(itemDto.getManufacturerName());

        Assertions.assertEquals(item.getId(), itemDto.getId());
        Assertions.assertEquals(item.getName(), itemDto.getName());
        Assertions.assertEquals(item.getPrice(), itemDto.getPrice());
        Assertions.assertEquals(item.getQuantity(), itemDto.getQuantity());
        Assertions.assertEquals(item.getManufacturer().getId(), itemDto.getManufacturerId());
        Assertions.assertEquals(item.getManufacturer().getName(), itemDto.getManufacturerName());
    }

    @Test
    void convertDtoToEntityTest() {
        ItemDto itemDto = ItemDto.builder()
                .id(2L)
                .name("MacBook Air M2")
                .price(1199)
                .quantity(30)
                .manufacturerId(1L)
                .manufacturerName("USA")
                .build();

        Item item = itemMapper.toEntity(itemDto);

        Assertions.assertNotNull(item);
        Assertions.assertNotNull(item.getId());
        Assertions.assertNotNull(item.getName());
        Assertions.assertNotNull(item.getPrice());
        Assertions.assertNotNull(item.getQuantity());
        Assertions.assertNotNull(item.getManufacturer());
        Assertions.assertNotNull(item.getManufacturer().getId());

        Assertions.assertEquals(itemDto.getId(), item.getId());
        Assertions.assertEquals(itemDto.getName(), item.getName());
        Assertions.assertEquals(itemDto.getPrice(), item.getPrice());
        Assertions.assertEquals(itemDto.getQuantity(), item.getQuantity());
        Assertions.assertEquals(itemDto.getManufacturerId(), item.getManufacturer().getId());
    }

    @Test
    void convertEntityListToDtoListTest() {
        Country usa = Country.builder().id(1L).name("USA").code("US").build();
        Country china = Country.builder().id(2L).name("China").code("CN").build();
        Country germany = Country.builder().id(3L).name("Germany").code("DE").build();

        List<Item> items = new ArrayList<>();
        items.add(Item.builder().id(1L).name("iPhone 15 Pro").price(999).quantity(50).manufacturer(usa).build());
        items.add(Item.builder().id(2L).name("MacBook Air M2").price(1199).quantity(30).manufacturer(usa).build());
        items.add(Item.builder().id(3L).name("Xiaomi 13 Pro").price(699).quantity(100).manufacturer(china).build());
        items.add(Item.builder().id(4L).name("Mercedes S-Class").price(95000).quantity(10).manufacturer(germany).build());

        List<ItemDto> itemDtoList = itemMapper.toDtoList(items);

        Assertions.assertNotNull(itemDtoList);
        Assertions.assertNotEquals(0, itemDtoList.size());
        Assertions.assertEquals(items.size(), itemDtoList.size());

        for (int i = 0; i < items.size(); i++) {
            Item item = items.get(i);
            ItemDto itemDto = itemDtoList.get(i);

            Assertions.assertNotNull(itemDto);
            Assertions.assertNotNull(itemDto.getId());
            Assertions.assertNotNull(itemDto.getName());
            Assertions.assertNotNull(itemDto.getManufacturerId());
            Assertions.assertNotNull(itemDto.getManufacturerName());

            Assertions.assertEquals(item.getId(), itemDto.getId());
            Assertions.assertEquals(item.getName(), itemDto.getName());
            Assertions.assertEquals(item.getPrice(), itemDto.getPrice());
            Assertions.assertEquals(item.getQuantity(), itemDto.getQuantity());
            Assertions.assertEquals(item.getManufacturer().getId(), itemDto.getManufacturerId());
            Assertions.assertEquals(item.getManufacturer().getName(), itemDto.getManufacturerName());
        }
    }

    @Test
    void convertDtoListToEntityListTest() {
        List<ItemDto> itemDtos = new ArrayList<>();
        itemDtos.add(ItemDto.builder().id(1L).name("Sony PlayStation 5").price(499).quantity(200).manufacturerId(4L).manufacturerName("Japan").build());
        itemDtos.add(ItemDto.builder().id(2L).name("Canon EOS R5").price(3899).quantity(25).manufacturerId(4L).manufacturerName("Japan").build());
        itemDtos.add(ItemDto.builder().id(3L).name("Samsung Galaxy S24").price(899).quantity(150).manufacturerId(5L).manufacturerName("South Korea").build());

        List<Item> items = itemMapper.toEntityList(itemDtos);

        Assertions.assertNotNull(items);
        Assertions.assertNotEquals(0, items.size());
        Assertions.assertEquals(itemDtos.size(), items.size());

        for (int i = 0; i < itemDtos.size(); i++) {
            ItemDto itemDto = itemDtos.get(i);
            Item item = items.get(i);

            Assertions.assertNotNull(item);
            Assertions.assertNotNull(item.getId());
            Assertions.assertNotNull(item.getName());
            Assertions.assertNotNull(item.getManufacturer());
            Assertions.assertNotNull(item.getManufacturer().getId());

            Assertions.assertEquals(itemDto.getId(), item.getId());
            Assertions.assertEquals(itemDto.getName(), item.getName());
            Assertions.assertEquals(itemDto.getPrice(), item.getPrice());
            Assertions.assertEquals(itemDto.getQuantity(), item.getQuantity());
            Assertions.assertEquals(itemDto.getManufacturerId(), item.getManufacturer().getId());
        }
    }

    @Test
    void shouldHandleNullValuesTest() {
        ItemDto nullDto = itemMapper.toDto(null);
        Assertions.assertNull(nullDto);

        Item nullEntity = itemMapper.toEntity(null);
        Assertions.assertNull(nullEntity);
    }

    @Test
    void shouldMapFieldsCorrectlyTest() {
        Country manufacturer = Country.builder()
                .id(5L)
                .name("South Korea")
                .code("KR")
                .build();

        Item item = Item.builder()
                .id(10L)
                .name("LG OLED TV")
                .price(1799)
                .quantity(40)
                .manufacturer(manufacturer)
                .build();

        ItemDto itemDto = itemMapper.toDto(item);

        Assertions.assertEquals(manufacturer.getId(), itemDto.getManufacturerId());
        Assertions.assertEquals(manufacturer.getName(), itemDto.getManufacturerName());
    }
}
