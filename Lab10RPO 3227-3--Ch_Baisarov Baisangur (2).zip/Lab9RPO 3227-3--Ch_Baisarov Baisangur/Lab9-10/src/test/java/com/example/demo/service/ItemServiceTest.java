package com.example.demo.service;

import com.example.demo.dto.CountryDto;
import com.example.demo.dto.ItemDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;

@SpringBootTest
@Transactional
class ItemServiceTest {

    @Autowired
    private ItemService itemService;

    @Autowired
    private CountryService countryService;

    @Test
    void findAllItemsTest() {
        List<ItemDto> items = itemService.findAll();
        Assertions.assertNotNull(items);
        Assertions.assertNotEquals(0, items.size());

        for (ItemDto itemDto : items) {
            Assertions.assertNotNull(itemDto);
            Assertions.assertNotNull(itemDto.getId());
            Assertions.assertNotNull(itemDto.getName());
            Assertions.assertNotNull(itemDto.getPrice());
            Assertions.assertNotNull(itemDto.getQuantity());
            Assertions.assertNotNull(itemDto.getManufacturerId());
        }

        Assertions.assertTrue(items.size() >= 10);
    }

    @Test
    void findItemByIdTest() {
        List<ItemDto> allItems = itemService.findAll();
        Assertions.assertFalse(allItems.isEmpty());

        Random random = new Random();
        Long existingItemId = allItems.get(random.nextInt(allItems.size())).getId();

        ItemDto itemDto = itemService.findById(existingItemId);
        Assertions.assertNotNull(itemDto);
        Assertions.assertNotNull(itemDto.getId());
        Assertions.assertNotNull(itemDto.getName());
        Assertions.assertNotNull(itemDto.getPrice());
        Assertions.assertNotNull(itemDto.getQuantity());
        Assertions.assertNotNull(itemDto.getManufacturerId());
        Assertions.assertEquals(existingItemId, itemDto.getId());

        Assertions.assertNull(itemService.findById(-999L));
    }

    @Test
    void createItemTest() {
        Long manufacturerId = countryService.findAll().get(0).getId();

        ItemDto itemDto = ItemDto.builder()
                .name("Test Product")
                .price(1500)
                .quantity(25)
                .manufacturerId(manufacturerId)
                .build();

        ItemDto createdItem = itemService.create(itemDto);

        Assertions.assertNotNull(createdItem);
        Assertions.assertNotNull(createdItem.getId());
        Assertions.assertNotNull(createdItem.getName());
        Assertions.assertNotNull(createdItem.getPrice());
        Assertions.assertNotNull(createdItem.getQuantity());
        Assertions.assertNotNull(createdItem.getManufacturerId());

        Assertions.assertEquals(itemDto.getName(), createdItem.getName());
        Assertions.assertEquals(itemDto.getPrice(), createdItem.getPrice());
        Assertions.assertEquals(itemDto.getQuantity(), createdItem.getQuantity());
        Assertions.assertEquals(itemDto.getManufacturerId(), createdItem.getManufacturerId());

        ItemDto checkItem = itemService.findById(createdItem.getId());
        Assertions.assertNotNull(checkItem);
        Assertions.assertEquals(createdItem.getId(), checkItem.getId());
        Assertions.assertEquals(createdItem.getName(), checkItem.getName());
        Assertions.assertEquals(createdItem.getPrice(), checkItem.getPrice());
        Assertions.assertEquals(createdItem.getQuantity(), checkItem.getQuantity());
        Assertions.assertEquals(createdItem.getManufacturerId(), checkItem.getManufacturerId());
    }

    @Test
    void updateItemTest() {
        List<ItemDto> allItems = itemService.findAll();
        Assertions.assertFalse(allItems.isEmpty());

        Long existingItemId = allItems.get(new Random().nextInt(allItems.size())).getId();
        Long newManufacturerId = countryService.findAll().get(0).getId();

        ItemDto updateDto = ItemDto.builder()
                .id(existingItemId)
                .name("Updated Product Name")
                .price(2000)
                .quantity(15)
                .manufacturerId(newManufacturerId)
                .build();

        ItemDto updatedItem = itemService.update(existingItemId, updateDto);

        Assertions.assertNotNull(updatedItem);
        Assertions.assertNotNull(updatedItem.getId());
        Assertions.assertNotNull(updatedItem.getName());
        Assertions.assertNotNull(updatedItem.getPrice());
        Assertions.assertNotNull(updatedItem.getQuantity());
        Assertions.assertNotNull(updatedItem.getManufacturerId());

        Assertions.assertEquals(existingItemId, updatedItem.getId());
        Assertions.assertEquals(updateDto.getName(), updatedItem.getName());
        Assertions.assertEquals(updateDto.getPrice(), updatedItem.getPrice());
        Assertions.assertEquals(updateDto.getQuantity(), updatedItem.getQuantity());
        Assertions.assertEquals(updateDto.getManufacturerId(), updatedItem.getManufacturerId());

        ItemDto checkItem = itemService.findById(updatedItem.getId());
        Assertions.assertNotNull(checkItem);
        Assertions.assertEquals(updatedItem.getId(), checkItem.getId());
        Assertions.assertEquals(updatedItem.getName(), checkItem.getName());
        Assertions.assertEquals(updatedItem.getPrice(), checkItem.getPrice());
        Assertions.assertEquals(updatedItem.getQuantity(), checkItem.getQuantity());
    }

    @Test
    void deleteItemTest() {
        Long manufacturerId = countryService.findAll().get(0).getId();

        ItemDto createdItem = itemService.create(
                ItemDto.builder()
                        .name("Product to Delete")
                        .price(500)
                        .quantity(10)
                        .manufacturerId(manufacturerId)
                        .build()
        );

        Long itemIdToDelete = createdItem.getId();
        Assertions.assertNotNull(itemService.findById(itemIdToDelete));

        Assertions.assertDoesNotThrow(() -> itemService.delete(itemIdToDelete));
        Assertions.assertNull(itemService.findById(itemIdToDelete));

        Assertions.assertThrows(RuntimeException.class, () -> itemService.delete(-999L));
    }

    @Test
    void findItemsByManufacturerTest() {
        Long manufacturerId = countryService.findAll().get(0).getId();
        List<ItemDto> items = itemService.findByManufacturer(manufacturerId);

        Assertions.assertNotNull(items);

        for (ItemDto itemDto : items) {
            Assertions.assertNotNull(itemDto);
            Assertions.assertNotNull(itemDto.getManufacturerId());
            Assertions.assertEquals(manufacturerId, itemDto.getManufacturerId());
        }
    }

    @Test
    void testManyToOneRelationshipTest() {
        List<ItemDto> items = itemService.findAll();
        Assertions.assertFalse(items.isEmpty());

        for (ItemDto itemDto : items) {
            Assertions.assertNotNull(itemDto.getManufacturerId());
            Assertions.assertNotNull(itemDto.getManufacturerName());

            CountryDto manufacturer = countryService.findById(itemDto.getManufacturerId());
            Assertions.assertNotNull(manufacturer);
            Assertions.assertEquals(manufacturer.getName(), itemDto.getManufacturerName());
        }
    }

    @Test
    void shouldCreateMultipleItemsFromSameManufacturerTest() {
        Long manufacturerId = countryService.findAll().get(0).getId();

        int initialSize = itemService.findByManufacturer(manufacturerId).size();

        ItemDto item1 = itemService.create(
                ItemDto.builder().name("Product 1").price(100).quantity(10).manufacturerId(manufacturerId).build()
        );
        ItemDto item2 = itemService.create(
                ItemDto.builder().name("Product 2").price(200).quantity(20).manufacturerId(manufacturerId).build()
        );
        ItemDto item3 = itemService.create(
                ItemDto.builder().name("Product 3").price(300).quantity(30).manufacturerId(manufacturerId).build()
        );

        Assertions.assertNotNull(item1.getId());
        Assertions.assertNotNull(item2.getId());
        Assertions.assertNotNull(item3.getId());

        List<ItemDto> manufacturerItems = itemService.findByManufacturer(manufacturerId);
        Assertions.assertEquals(initialSize + 3, manufacturerItems.size());
    }


    @Test
    void shouldChangeItemManufacturerTest() {
        List<CountryDto> countries = countryService.findAll();
        Long manufacturer1Id = countries.get(0).getId();
        Long manufacturer2Id = countries.get(1).getId();

        ItemDto createdItem = itemService.create(
                ItemDto.builder()
                        .name("Product with changing manufacturer")
                        .price(500)
                        .quantity(50)
                        .manufacturerId(manufacturer1Id)
                        .build()
        );

        Assertions.assertEquals(manufacturer1Id, createdItem.getManufacturerId());

        ItemDto updateDto = ItemDto.builder()
                .id(createdItem.getId())
                .name(createdItem.getName())
                .price(createdItem.getPrice())
                .quantity(createdItem.getQuantity())
                .manufacturerId(manufacturer2Id)
                .build();

        ItemDto updatedItem = itemService.update(createdItem.getId(), updateDto);

        Assertions.assertEquals(manufacturer2Id, updatedItem.getManufacturerId());
        Assertions.assertNotEquals(manufacturer1Id, updatedItem.getManufacturerId());
    }
}
