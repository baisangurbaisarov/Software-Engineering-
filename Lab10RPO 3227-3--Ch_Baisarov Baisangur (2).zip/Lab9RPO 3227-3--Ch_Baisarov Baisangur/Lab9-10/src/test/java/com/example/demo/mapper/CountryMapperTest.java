package com.example.demo.mapper;

import com.example.demo.dto.CountryDto;
import com.example.demo.entity.Country;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
class CountryMapperTest {

    @Autowired
    private CountryMapper countryMapper;

    @Test
    void convertEntityToDtoTest() {
        Country country = Country.builder()
                .id(1L)
                .name("USA")
                .code("US")
                .build();
        CountryDto countryDto = countryMapper.toDto(country);

        Assertions.assertNotNull(countryDto);

        Assertions.assertNotNull(countryDto.getId());
        Assertions.assertNotNull(countryDto.getName());
        Assertions.assertNotNull(countryDto.getCode());

        Assertions.assertEquals(country.getId(), countryDto.getId());
        Assertions.assertEquals(country.getName(), countryDto.getName());
        Assertions.assertEquals(country.getCode(), countryDto.getCode());
    }

    @Test
    void convertDtoToEntityTest() {
        CountryDto countryDto = CountryDto.builder()
                .id(2L)
                .name("China")
                .code("CN")
                .build();

        Country country = countryMapper.toEntity(countryDto);

        Assertions.assertNotNull(country);

        Assertions.assertNotNull(country.getId());
        Assertions.assertNotNull(country.getName());
        Assertions.assertNotNull(country.getCode());

        Assertions.assertEquals(countryDto.getId(), country.getId());
        Assertions.assertEquals(countryDto.getName(), country.getName());
        Assertions.assertEquals(countryDto.getCode(), country.getCode());
    }

    @Test
    void convertEntityListToDtoListTest() {
        List<Country> countries = new ArrayList<>();
        countries.add(Country.builder().id(1L).name("USA").code("US").build());
        countries.add(Country.builder().id(2L).name("China").code("CN").build());
        countries.add(Country.builder().id(3L).name("Germany").code("DE").build());
        countries.add(Country.builder().id(4L).name("Japan").code("JP").build());

        List<CountryDto> countryDtoList = countryMapper.toDtoList(countries);

        Assertions.assertNotNull(countryDtoList);

        Assertions.assertNotEquals(0, countryDtoList.size());

        Assertions.assertEquals(countries.size(), countryDtoList.size());

        for (int i = 0; i < countries.size(); i++) {
            Country country = countries.get(i);
            CountryDto countryDto = countryDtoList.get(i);

            Assertions.assertNotNull(countryDto);
            Assertions.assertNotNull(countryDto.getId());
            Assertions.assertNotNull(countryDto.getName());
            Assertions.assertNotNull(countryDto.getCode());

            Assertions.assertEquals(country.getId(), countryDto.getId());
            Assertions.assertEquals(country.getName(), countryDto.getName());
            Assertions.assertEquals(country.getCode(), countryDto.getCode());
        }
    }

    @Test
    void convertDtoListToEntityListTest() {

        List<CountryDto> countryDtos = new ArrayList<>();
        countryDtos.add(CountryDto.builder().id(1L).name("Japan").code("JP").build());
        countryDtos.add(CountryDto.builder().id(2L).name("South Korea").code("KR").build());

        List<Country> countries = countryMapper.toEntityList(countryDtos);

        Assertions.assertNotNull(countries);

        Assertions.assertNotEquals(0, countries.size());

        Assertions.assertEquals(countryDtos.size(), countries.size());

        for (int i = 0; i < countryDtos.size(); i++) {
            CountryDto countryDto = countryDtos.get(i);
            Country country = countries.get(i);

            Assertions.assertNotNull(country);
            Assertions.assertNotNull(country.getId());
            Assertions.assertNotNull(country.getName());
            Assertions.assertNotNull(country.getCode());

            Assertions.assertEquals(countryDto.getId(), country.getId());
            Assertions.assertEquals(countryDto.getName(), country.getName());
            Assertions.assertEquals(countryDto.getCode(), country.getCode());
        }
    }

    @Test
    void shouldHandleNullValuesTest() {

        CountryDto nullDto = countryMapper.toDto(null);
        Assertions.assertNull(nullDto);

        Country nullEntity = countryMapper.toEntity(null);
        Assertions.assertNull(nullEntity);
    }
}