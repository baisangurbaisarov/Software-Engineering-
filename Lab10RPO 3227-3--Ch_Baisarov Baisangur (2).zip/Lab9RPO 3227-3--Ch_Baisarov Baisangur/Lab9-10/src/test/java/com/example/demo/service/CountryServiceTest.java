package com.example.demo.service;

import com.example.demo.dto.CountryDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;

@SpringBootTest
@Transactional
class CountryServiceTest {

    @Autowired
    private CountryService countryService;

    @Test
    void findAllCountriesTest() {
        List<CountryDto> countries = countryService.findAll();

        Assertions.assertNotNull(countries);
        Assertions.assertNotEquals(0, countries.size());

        for (CountryDto countryDto : countries) {
            Assertions.assertNotNull(countryDto);
            Assertions.assertNotNull(countryDto.getId());
            Assertions.assertNotNull(countryDto.getName());
            Assertions.assertNotNull(countryDto.getCode());
        }

        Assertions.assertTrue(countries.size() >= 5);
    }

    @Test
    void findCountryByIdTest() {
        List<CountryDto> allCountries = countryService.findAll();
        Assertions.assertFalse(allCountries.isEmpty());

        Random random = new Random();
        int randomIndex = random.nextInt(allCountries.size());

        Long existingCountryId = allCountries.get(randomIndex).getId();

        CountryDto countryDto = countryService.findById(existingCountryId);

        Assertions.assertNotNull(countryDto);
        Assertions.assertNotNull(countryDto.getId());
        Assertions.assertNotNull(countryDto.getName());
        Assertions.assertNotNull(countryDto.getCode());

        Assertions.assertEquals(existingCountryId, countryDto.getId());

        CountryDto nonExistentCountry = countryService.findById(-999L);
        Assertions.assertNull(nonExistentCountry);
    }

    @Test
    void createCountryTest() {
        CountryDto countryDto = CountryDto.builder()
                .name("France")
                .code("FR")
                .build();

        CountryDto createdCountry = countryService.create(countryDto);

        Assertions.assertNotNull(createdCountry);
        Assertions.assertNotNull(createdCountry.getId());
        Assertions.assertNotNull(createdCountry.getName());
        Assertions.assertNotNull(createdCountry.getCode());

        Assertions.assertEquals(countryDto.getName(), createdCountry.getName());
        Assertions.assertEquals(countryDto.getCode(), createdCountry.getCode());

        CountryDto checkCountry = countryService.findById(createdCountry.getId());

        Assertions.assertNotNull(checkCountry);
        Assertions.assertEquals(createdCountry.getId(), checkCountry.getId());
        Assertions.assertEquals(createdCountry.getName(), checkCountry.getName());
        Assertions.assertEquals(createdCountry.getCode(), checkCountry.getCode());
    }

    @Test
    void updateCountryTest() {
        List<CountryDto> allCountries = countryService.findAll();
        Assertions.assertFalse(allCountries.isEmpty());

        Random random = new Random();
        Long existingCountryId = allCountries.get(random.nextInt(allCountries.size())).getId();

        CountryDto updateDto = CountryDto.builder()
                .id(existingCountryId)
                .name("Updated Country Name")
                .code("UC")
                .build();

        CountryDto updatedCountry = countryService.update(existingCountryId, updateDto);

        Assertions.assertNotNull(updatedCountry);
        Assertions.assertNotNull(updatedCountry.getId());
        Assertions.assertNotNull(updatedCountry.getName());
        Assertions.assertNotNull(updatedCountry.getCode());

        Assertions.assertEquals(existingCountryId, updatedCountry.getId());
        Assertions.assertEquals(updateDto.getName(), updatedCountry.getName());
        Assertions.assertEquals(updateDto.getCode(), updatedCountry.getCode());

        CountryDto checkCountry = countryService.findById(updatedCountry.getId());

        Assertions.assertNotNull(checkCountry);
        Assertions.assertEquals(updatedCountry.getId(), checkCountry.getId());
        Assertions.assertEquals(updatedCountry.getName(), checkCountry.getName());
        Assertions.assertEquals(updatedCountry.getCode(), checkCountry.getCode());
    }

    @Test
    void deleteCountryTest() {
        CountryDto countryDto = CountryDto.builder()
                .name("Test Country for Deletion")
                .code("TD")
                .build();

        CountryDto createdCountry = countryService.create(countryDto);
        Long countryIdToDelete = createdCountry.getId();

        Assertions.assertNotNull(countryService.findById(countryIdToDelete));

        Assertions.assertDoesNotThrow(() -> countryService.delete(countryIdToDelete));

        CountryDto deletedCountry = countryService.findById(countryIdToDelete);
        Assertions.assertNull(deletedCountry);

        Assertions.assertThrows(RuntimeException.class, () -> countryService.delete(-999L));
    }

    @Test
    void shouldCreateMultipleCountriesTest() {
        int initialSize = countryService.findAll().size();

        CountryDto country1 = countryService.create(
                CountryDto.builder().name("Italy").code("IT").build()
        );
        CountryDto country2 = countryService.create(
                CountryDto.builder().name("Spain").code("ES").build()
        );
        CountryDto country3 = countryService.create(
                CountryDto.builder().name("Portugal").code("PT").build()
        );

        Assertions.assertNotNull(country1.getId());
        Assertions.assertNotNull(country2.getId());
        Assertions.assertNotNull(country3.getId());

        List<CountryDto> allCountries = countryService.findAll();
        Assertions.assertEquals(initialSize + 3, allCountries.size());
    }
}
