package com.example.demo.dto;

import lombok.*;
import java.util.List;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductDto {
    private Long id;
    private String name;
    private double price;
    private String description;

    private CategoryDto category;

    private Set<TagDto> tags;
}