package com.example.demo.service;

import com.example.demo.dto.CategoryDto;
import java.util.List;

public interface CategoryService {
    List<CategoryDto> getCategories();
    CategoryDto getCategory(Long id);
    CategoryDto addCategory(CategoryDto dto);
    CategoryDto updateCategory(Long id, CategoryDto dto);
    boolean deleteCategory(Long id);
}