package com.example.demo.service.impl;

import com.example.demo.dto.TagDto;
import com.example.demo.entity.Tag;
import com.example.demo.repository.TagRepository;
import com.example.demo.service.TagService;
import com.example.demo.mapper.TagMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional
public class TagServiceImpl implements TagService {

    private final TagRepository tagRepository;
    private final TagMapper tagMapper;

    @Override
    public List<TagDto> getTags() {
        List<Tag> tags = tagRepository.findAll();
        return tagMapper.toDtoList(tags);
    }

    @Override
    public TagDto getTag(Long id) {
        Tag tag = tagRepository.findById(id).orElse(null);
        if (Objects.isNull(tag)) {
            return null;
        }
        return tagMapper.toDto(tag);
    }

    @Override
    public TagDto getTagByName(String name) {
        Tag tag = tagRepository.findByName(normalizeName(name)).orElse(null);
        if (Objects.isNull(tag)) {
            return null;
        }
        return tagMapper.toDto(tag);
    }

    @Override
    public TagDto addTag(TagDto dto) {
        String normalizedName = normalizeName(dto.getName());
        Optional<Tag> existing = tagRepository.findByName(normalizedName);

        if (existing.isPresent()) {
            throw new RuntimeException("Tag with name '" + normalizedName + "' already exists");
        }

        Tag tag = tagMapper.toEntity(dto);
        tag.setName(normalizedName);
        Tag saved = tagRepository.save(tag);
        return tagMapper.toDto(saved);
    }

    @Override
    public TagDto updateTag(Long id, TagDto dto) {
        Tag tag = tagRepository.findById(id).orElse(null);
        if (Objects.isNull(tag)) {
            return null;
        }

        String normalizedName = normalizeName(dto.getName());

        Optional<Tag> existing = tagRepository.findByName(normalizedName);
        if (existing.isPresent() && !existing.get().getId().equals(id)) {
            throw new RuntimeException("Tag with name '" + normalizedName + "' already exists");
        }

        tag.setName(normalizedName);
        Tag updated = tagRepository.save(tag);
        return tagMapper.toDto(updated);
    }

    @Override
    public boolean deleteTag(Long id) {
        if (!tagRepository.existsById(id)) {
            return false;
        }
        tagRepository.deleteById(id);
        return true;
    }

    @Override
    public TagDto findOrCreateTag(String name) {
        String normalizedName = normalizeName(name);

        Optional<Tag> existing = tagRepository.findByName(normalizedName);
        if (existing.isPresent()) {
            return tagMapper.toDto(existing.get());
        }

        Tag newTag = new Tag();
        newTag.setName(normalizedName);
        Tag saved = tagRepository.save(newTag);
        return tagMapper.toDto(saved);
    }

    private String normalizeName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Tag name cannot be null");
        }
        return name.trim().toLowerCase();
    }
}