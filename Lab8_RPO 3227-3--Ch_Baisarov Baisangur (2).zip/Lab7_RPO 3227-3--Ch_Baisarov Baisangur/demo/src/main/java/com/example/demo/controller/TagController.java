package com.example.demo.controller;

import com.example.demo.dto.TagDto;
import com.example.demo.service.TagService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequiredArgsConstructor
@RequestMapping("/tags")
public class TagController {

    private final TagService tagService;

    @GetMapping
    public ResponseEntity<?> getTags() {
        List<TagDto> tags = tagService.getTags();
        if (tags.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return ResponseEntity.ok(tags);
    }
    @GetMapping("/{id}")
    public ResponseEntity<?> getTag(@PathVariable Long id) {
        TagDto tag = tagService.getTag(id);
        if (Objects.isNull(tag)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok(tag);
    }
    @GetMapping("/search")
    public ResponseEntity<?> getTagByName(@RequestParam String name) {
        TagDto tag = tagService.getTagByName(name);
        if (Objects.isNull(tag)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok(tag);
    }
    @PostMapping
    public ResponseEntity<?> addTag(@RequestBody TagDto dto) {
        try {
            TagDto created = tagService.addTag(dto);
            return new ResponseEntity<>(created, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> updateTag(@PathVariable Long id, @RequestBody TagDto dto) {
        try {
            TagDto updated = tagService.updateTag(id, dto);
            if (Objects.isNull(updated)) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTag(@PathVariable Long id) {
        boolean deleted = tagService.deleteTag(id);
        if (!deleted) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok("Tag deleted successfully");
    }
}