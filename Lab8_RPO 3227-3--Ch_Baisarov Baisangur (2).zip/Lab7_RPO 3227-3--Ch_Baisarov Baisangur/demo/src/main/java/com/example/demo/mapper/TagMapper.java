package com.example.demo.mapper;

import com.example.demo.dto.ProductDto;
import com.example.demo.dto.TagDto;
import com.example.demo.entity.Product;
import com.example.demo.entity.Tag;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;
import java.util.Set;

@Mapper(componentModel = "spring")
public interface TagMapper {

    @Mapping(target = "products", ignore = true)
    TagDto toDto(Tag tag);

    @Mapping(target = "products", ignore = true)
    Tag toEntity(TagDto dto);

    Set<TagDto> toDtoSet(Set<Tag> tags);
    List<TagDto> toDtoList(List<Tag> tags);
}