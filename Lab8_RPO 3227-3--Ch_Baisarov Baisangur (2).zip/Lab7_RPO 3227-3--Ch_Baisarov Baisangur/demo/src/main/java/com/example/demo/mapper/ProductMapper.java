package com.example.demo.mapper;

import com.example.demo.dto.ProductDto;
import com.example.demo.entity.Product;
import org.mapstruct.*;

import java.util.List;

@Mapper(
        componentModel = "spring",
        uses = {CategoryMapper.class, TagMapper.class}
)
public interface ProductMapper {

    List<ProductDto> toDtoList(List<Product> products);

    ProductDto toDto(Product updatedProduct);

    Product toEntity(ProductDto dto);
}