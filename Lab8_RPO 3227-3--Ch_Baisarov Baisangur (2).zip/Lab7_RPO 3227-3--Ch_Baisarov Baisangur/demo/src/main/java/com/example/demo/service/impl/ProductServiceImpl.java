package com.example.demo.service.impl;

import com.example.demo.dto.ProductDto;
import com.example.demo.dto.TagDto;
import com.example.demo.entity.Product;
import com.example.demo.entity.Category;
import com.example.demo.entity.Tag;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.TagRepository;
import com.example.demo.service.ProductService;
import com.example.demo.service.TagService; // НОВОЕ: импортируем TagService
import com.example.demo.mapper.ProductMapper;
import com.example.demo.mapper.TagMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final TagRepository tagRepository;
    private final ProductMapper productMapper;
    private final TagService tagService;
    private final TagMapper tagMapper;

    @Override
    public List<ProductDto> getProducts() {
        List<Product> products = productRepository.findAll();
        return productMapper.toDtoList(products);
    }

    @Override
    public ProductDto addProduct(ProductDto dto) {
        Product product = productMapper.toEntity(dto);

        if (dto.getCategory() != null && dto.getCategory().getId() != null) {
            Category category = categoryRepository.findById(dto.getCategory().getId())
                    .orElseThrow(() -> new RuntimeException("Category not found"));
            product.setCategory(category);
        }

        if (dto.getTags() != null && !dto.getTags().isEmpty()) {
            Set<Tag> tags = dto.getTags().stream()
                    .map(tagDto -> {
                        TagDto foundOrCreated = tagService.findOrCreateTag(tagDto.getName());
                        return tagMapper.toEntity(foundOrCreated);
                    })
                    .collect(Collectors.toSet());
            product.setTags(tags);
        }

        Product savedProduct = productRepository.save(product);
        return productMapper.toDto(savedProduct);
    }

    @Override
    public ProductDto getProduct(Long id) {
        Product product = productRepository.findById(id).orElse(null);
        if (Objects.isNull(product)) {
            return null;
        }
        return productMapper.toDto(product);
    }

    @Override
    public ProductDto updateProduct(Long id, ProductDto dto) {
        Product existingProduct = productRepository.findById(id).orElse(null);
        if (Objects.isNull(existingProduct)) {
            return null;
        }

        existingProduct.setName(dto.getName());
        existingProduct.setPrice(dto.getPrice());
        existingProduct.setDescription(dto.getDescription());

        if (dto.getCategory() != null && dto.getCategory().getId() != null) {
            Category category = categoryRepository.findById(dto.getCategory().getId())
                    .orElseThrow(() -> new RuntimeException("Category not found"));
            existingProduct.setCategory(category);
        }
        if (dto.getTags() != null) {
            Set<Tag> tags = dto.getTags().stream()
                    .map(tagDto -> {
                        TagDto foundOrCreated = tagService.findOrCreateTag(tagDto.getName());
                        return tagMapper.toEntity(foundOrCreated);
                    })
                    .collect(Collectors.toSet());
            existingProduct.setTags(tags);
        }

        Product updatedProduct = productRepository.save(existingProduct);
        return productMapper.toDto(updatedProduct);
    }

    @Override
    public boolean deleteProduct(Long id) {
        ProductDto checkProduct = getProduct(id);
        if (Objects.isNull(checkProduct)) {
            return false;
        }
        productRepository.deleteById(id);
        return true;
    }
}