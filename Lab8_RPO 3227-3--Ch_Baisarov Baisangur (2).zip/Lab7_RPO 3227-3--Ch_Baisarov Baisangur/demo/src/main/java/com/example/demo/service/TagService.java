package com.example.demo.service;

import com.example.demo.dto.TagDto;
import java.util.List;

public interface TagService {
    List<TagDto> getTags();
    TagDto getTag(Long id);
    TagDto getTagByName(String name);
    TagDto addTag(TagDto dto);
    TagDto updateTag(Long id, TagDto dto);
    boolean deleteTag(Long id);

    TagDto findOrCreateTag(String name);
}