package com.example.demo1.controller;

import com.example.demo1.model.Items;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ItemController {

    @GetMapping("/")
    public String getItems(Model model) {
        List<Items> products = new ArrayList<>();
        products.add(new Items(1L, "Phone", "Samsung", 3000.0));
        products.add(new Items(2L, "NoteBook", "Lenovo IdeaPad", 6000.0));
        products.add(new Items(3L, "Earphone", "Sony WH-1000XM5", 2500.0));
        products.add(new Items(1L, "Phone", "Samsung", 3001.0));
        products.add(new Items(2L, "NoteBook", "Lenovo IdeaPad", 6001.0));
        products.add(new Items(3L, "Earphone", "Sony WH-1000XM5", 2501.0));

        model.addAttribute("products", products);
        return "index";
    }
}
