package com.example.demo.service;

import com.example.demo.model.Task;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class TaskService {
    private List<Task> tasks = new ArrayList<>();
    private AtomicLong counter = new AtomicLong();

    public List<Task> getAllTasks(){
        return tasks;
    }

    public void addTask(Task task){
        task.setId(counter.getAndIncrement());
        tasks.add(task);
    }

    public Optional<Task> getTaskById(Long id) {
        return tasks.stream().filter(t -> t.getId().equals(id)).findFirst();
    }

    public void updateTask(Task updatedTask) {
        getTaskById(updatedTask.getId()).ifPresent(task -> {
            task.setName(updatedTask.getName());
            task.setDeadlineDate(updatedTask.getDeadlineDate());
            task.setCompleted(updatedTask.isCompleted());
        });
    }

    public void deleteTask(Long id) {
        tasks.removeIf(task -> task.getId().equals(id));
    }
}
