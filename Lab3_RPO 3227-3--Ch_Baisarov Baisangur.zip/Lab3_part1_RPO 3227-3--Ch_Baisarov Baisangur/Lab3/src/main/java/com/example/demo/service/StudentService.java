package com.example.demo.service;

import com.example.demo.model.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class StudentService {
    private List<Student> students = new ArrayList<>();
    private AtomicLong counter = new AtomicLong(1);

    public List<Student> getAllStudents(){
        return students;
    }

    public void addStudent(String name, String surname, int exam){
        String grade = calculateMark(exam);
        Student student = new Student(counter.getAndIncrement(), name, surname, exam, grade);
        students.add(student);
    }

    private String calculateMark(int exam){
        if (exam >= 90) return "A";
        else if (exam >= 75) return "B";
        else if (exam >= 60) return "C";
        else if (exam >= 50) return "D";
        else return "F";
    }
}
