package com.example.demo.controler;

import com.example.demo.dto.ItemDto;
import com.example.demo.service.CountryService;
import com.example.demo.service.ItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/items")
@RequiredArgsConstructor
public class ItemViewController {

    private final ItemService itemService;
    private final CountryService countryService;

    @GetMapping
    public String listItems(Model model) {
        model.addAttribute("items", itemService.findAll());
        return "items/list";
    }

    @GetMapping("/{id}")
    public String viewItem(@PathVariable Long id, Model model) {
        model.addAttribute("item", itemService.findById(id));
        return "items/view";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("item", new ItemDto());
        model.addAttribute("countries", countryService.findAll());
        return "items/form";
    }

    @PostMapping
    public String createItem(@ModelAttribute ItemDto itemDto) {
        itemService.create(itemDto);
        return "redirect:/items";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("item", itemService.findById(id));
        model.addAttribute("countries", countryService.findAll());
        return "items/form";
    }

    @PostMapping("/{id}")
    public String updateItem(@PathVariable Long id, @ModelAttribute ItemDto itemDto) {
        itemService.update(id, itemDto);
        return "redirect:/items";
    }

    @PostMapping("/{id}/delete")
    public String deleteItem(@PathVariable Long id) {
        itemService.delete(id);
        return "redirect:/items";
    }
}