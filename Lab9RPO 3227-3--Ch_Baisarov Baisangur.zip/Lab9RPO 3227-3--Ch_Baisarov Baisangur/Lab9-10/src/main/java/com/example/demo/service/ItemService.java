package com.example.demo.service;

import com.example.demo.dto.ItemDto;
import com.example.demo.entity.Country;
import com.example.demo.entity.Item;
import com.example.demo.mapper.ItemMapper;
import com.example.demo.repository.CountryRepository;
import com.example.demo.repository.ItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ItemService {

    private final ItemRepository itemRepository;
    private final CountryRepository countryRepository;
    private final ItemMapper itemMapper;

    public List<ItemDto> findAll() {
        return itemMapper.toDtoList(itemRepository.findAll());
    }

    public ItemDto findById(Long id) {
        Item item = itemRepository.findById(id).orElse(null);
        return itemMapper.toDto(item);
    }

    @Transactional
    public ItemDto create(ItemDto itemDto) {
        Country manufacturer = countryRepository.findById(itemDto.getManufacturerId()).orElse(null);

        Item item = itemMapper.toEntity(itemDto);
        item.setId(null);
        item.setManufacturer(manufacturer);

        Item saved = itemRepository.save(item);
        return itemMapper.toDto(saved);
    }

    @Transactional
    public ItemDto update(Long id, ItemDto itemDto) {
        Item existing = itemRepository.findById(id).orElse(null);

        existing.setName(itemDto.getName());
        existing.setPrice(itemDto.getPrice());
        existing.setQuantity(itemDto.getQuantity());

        if (itemDto.getManufacturerId() != null) {
            Country manufacturer = countryRepository.findById(itemDto.getManufacturerId()).orElse(null);
            existing.setManufacturer(manufacturer);
        }

        Item updated = itemRepository.save(existing);
        return itemMapper.toDto(updated);
    }

    @Transactional
    public void delete(Long id) {
        if (!itemRepository.existsById(id)) {
            throw new RuntimeException("Item not found with id: " + id);
        }
        itemRepository.deleteById(id);
    }

    public List<ItemDto> findByManufacturer(Long manufacturerId) {
        List<Item> items = itemRepository.findByManufacturerId(manufacturerId);
        return itemMapper.toDtoList(items);
    }
}
