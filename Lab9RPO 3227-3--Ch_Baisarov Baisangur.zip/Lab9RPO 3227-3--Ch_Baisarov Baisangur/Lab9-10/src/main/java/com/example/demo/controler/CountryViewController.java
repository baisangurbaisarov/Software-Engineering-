package com.example.demo.controler;

import com.example.demo.dto.CountryDto;
import com.example.demo.service.CountryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/countries")
@RequiredArgsConstructor
public class CountryViewController {

    private final CountryService countryService;

    @GetMapping
    public String listCountries(Model model) {
        model.addAttribute("countries", countryService.findAll());
        return "countries/list";
    }

    @GetMapping("/{id}")
    public String viewCountry(@PathVariable Long id, Model model) {
        model.addAttribute("country", countryService.findById(id));
        return "countries/view";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("country", new CountryDto());
        return "countries/form";
    }

    @PostMapping
    public String createCountry(@ModelAttribute CountryDto countryDto) {
        countryService.create(countryDto);
        return "redirect:/countries";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("country", countryService.findById(id));
        return "countries/form";
    }

    @PostMapping("/{id}")
    public String updateCountry(@PathVariable Long id, @ModelAttribute CountryDto countryDto) {
        countryService.update(id, countryDto);
        return "redirect:/countries";
    }

    @PostMapping("/{id}/delete")
    public String deleteCountry(@PathVariable Long id) {
        countryService.delete(id);
        return "redirect:/countries";
    }
}