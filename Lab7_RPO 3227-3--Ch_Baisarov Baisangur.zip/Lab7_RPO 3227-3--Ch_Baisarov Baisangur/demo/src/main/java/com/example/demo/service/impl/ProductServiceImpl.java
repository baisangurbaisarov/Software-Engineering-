package com.example.demo.service.impl;

import com.example.demo.dto.ProductDto;
import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;

    @Override
    public List<ProductDto> getProducts() {
        List<Product> products = productRepository.findAll();
        List<ProductDto> productDtoList = new ArrayList<>();
        products.forEach(product -> {
            ProductDto dto = toDto(product);
            productDtoList.add(dto);
        });
        return productDtoList;
    }

    @Override
    public ProductDto addProduct(ProductDto dto) {
        Product product = toEntity(dto);
        Product savedProduct = productRepository.save(product);
        return toDto(savedProduct);
    }

    @Override
    public ProductDto getProduct(Long id) {
        Product product = productRepository.findById(id).orElse(null);
        if (Objects.isNull(product)) {
            return null;
        }
        return toDto(product);
    }

    @Override
    public ProductDto updateProduct(Long id, ProductDto dto) {
        ProductDto checkProduct = getProduct(id);
        if (Objects.isNull(checkProduct)) {
            return null;
        }
        Product product = toEntity(dto);
        product.setId(id);
        Product updatedProduct = productRepository.save(product);
        return toDto(updatedProduct);
    }

    @Override
    public boolean deleteProduct(Long id) {
        ProductDto checkProduct = getProduct(id);
        if (Objects.isNull(checkProduct)) {
            return false;
        }
        productRepository.deleteById(id);
        return true;
    }

    private ProductDto toDto(Product product){
        return ProductDto.builder()
                .id(product.getId())
                .name(product.getName())
                .price(product.getPrice())
                .description(product.getDescription())
                .category(product.getCategory())
                .build();
    }

    private Product toEntity(ProductDto dto){
        Product product = new Product();
        product.setId(dto.getId());
        product.setName(dto.getName());
        product.setPrice(dto.getPrice());
        product.setDescription(dto.getDescription());
        product.setCategory(dto.getCategory());
        return product;
    }
}

